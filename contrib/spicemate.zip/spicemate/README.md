# SPICEMate

Efficient and accuracy-ensured waveform compression for transient circuit simulation (Demo V1.0)

*Statically built with g++ 4.8.5 under Ubuntu 16.04*

**Author**: Lingjie Li (li-lj18@mails.tsinghua.edu.cn)

**Supervisor**: Wenjian Yu (yu-wj@tsinghua.edu.cn)

Numbda, Dept. Computer Science & Technology, Tsinghua University, Beijing, China

## Usage

### Quick Guide

1. Prepare a raw waveform file. Here we use `test1.bin` as an example. For more details, see [Raw Waveform Format Specification](#raw-waveform-format-specification).
2. Check the contents of the waveform.
3. Compress the waveform with certain error tolerance.
4. Prepare an *idx* file containing the indices of the signals that need to be recovered.
5. Decompress (part of) the compressed file with the *idx* file.
6. Check the contents of the recovered waveform.

```
$ ./read-bin test1.bin | less

$ ./compress-bin test1.bin compressed 1e-3 1e-6
100% | 2039/2039 [00:00<00:00]
compressed waveform with 3 signals and 2039 points.

$ echo "0 1 2" > test1.idx

$ ./decompress-bin compressed recovered.bin test1.idx
decompressing waveform with 3 signals and 2039 points.
selecting 3 signals.
100% | 2039/2039 [00:00<00:00]

$ ./read-bin recovered.bin | less
```

### Executables

#### Waveform Reader: `read-bin`

Usage: `./read-bin waveform`

- `waveform`: the raw waveform file.

Output:
```
ns: {NUMBER OF SIGNALS}
nt: {NUMBER OF TIMEPOINTS}
...

*** X_{TIMEPOINT_IDX}: {TIME} ***
{SIGNAL_IDX} {SIGNAL_NAME} {SIGNAL_VALUE}
...
...
```

#### Waveform Compressor: `compress-bin`

Usage: `./compress-bin original_waveform compressed_waveform reltol abstol`

- `original_waveform`: the raw waveform file.
- `compressed_waveform`: the output file.
- `reltol`: relative error tolerance (suggested value: 1e-3).
- `abstol`: absolute error tolerance (suggested value: 1e-6).

#### Waveform Decompressor: `decompress-bin`

Usage: `./decompress-bin compressed_waveform decompressed_waveform idx_file`

- `compressed_waveform`: the output file of `compress-bin`.
- `decompressed_waveform`: the recovered raw waveform file.
- `idx_file`: a file containing the indices of the signals that need to be recovered.
    - The recovered waveform only contains the selected signals.
    - The indices should be in range [0, *ns*).

### Raw Waveform Format Specification

A raw waveform is a binary file that consists of the following blocks.

| Name  | Type        | Bytes       | Count | Explanation             |
|-------|-------------|-------------|-------|-------------------------|
| *ns*  | int32       | 4           | 1     | Number of signals       |
| *nt*  | int32       | 4           | 1     | Number of timepoints    |
| names | *String*    | ?           | *ns*  | Names of the signals    |
| tps   | *TimePoint* | 8\*(*ns*+1) | *nt*  | Data of each timepoints |

A *String* block is formed as follow:

| Name  | Type   | Bytes | Count | Explanation                     |
|-------|--------|-------|-------|---------------------------------|
| *len* | uint32 | 4     | 1     | Length of the string            |
| ch    | char   | 1     | *len* | Characters that form the string |

A *TimePoint* block is formed as follow:

| Name | Type   | Bytes | Count | Explanation               |
|------|--------|-------|-------|---------------------------|
| x    | double | 8     | 1     | X value (simulation time) |
| y    | double | 8     | *ns*  | Signal values             |

## Provided Test Cases

| Filename    | Size  | *ns* | *nt*   |
|-------------|-------|------|--------|
| `test1.bin` | 64Ki  | 3    | 2039   |
| `test2.bin` | 25Mi  | 6    | 471817 |
| `test3.bin` | 270Mi | 56   | 621466 |

Note that we also provided *idx* files for "full decompression" with each waveform file.

## Reference

[1] Lingjie Li and Wenjian Yu, "Efficient and accuracy-ensured waveform compression for transient circuit simulation," IEEE Trans. Comput.-Aided Design Integr. Circuits Syst., 40(7): 1437-1449, 2021.
