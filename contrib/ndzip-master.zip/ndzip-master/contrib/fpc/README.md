# FPC 1.1

FPC is a fast and effective lossless compressor/decompressor for IEEE 754 64-bit double-precision floating-point data
by Martin Burtscher.

FPC is included in this repository as third-party code for benchmarking purposes. See `fpc.c` for licensing details.
Small modifications have been made to the code to allow including it as a library.

Origin: https://userweb.cs.txstate.edu/~burtscher/research/FPC/
