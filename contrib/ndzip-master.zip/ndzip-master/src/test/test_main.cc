#include <ndzip/gpu_common.hh>  // this file is optionally compiled as a CUDA object

#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>
